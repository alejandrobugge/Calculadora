﻿Imports System.Data.SqlClient

Public Class WebForm1
    Inherits System.Web.UI.Page
    Private Conn As SqlConnection
    Private Cmd As SqlCommand
    Private Reader As SqlDataReader
    Private results As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Conn = New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB; " &
              "AttachDbFilename=|DataDirectory|\Calculadora.mdf;Integrated Security=True")

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles cmdCalcular.Click
        If ValidaDatos(txtNumero1.Text, txtNumero2.Text, cboOperacion.Text) Then
            Cmd = Conn.CreateCommand()
            Dim resultado As Double

            txtNumero1.Text = Replace(txtNumero1.Text, ",", ".")
            txtNumero2.Text = Replace(txtNumero2.Text, ",", ".")

            Cmd.CommandText = "exec sp_operacion " + txtNumero1.Text + "," &
                txtNumero2.Text + ",'" &
                cboOperacion.Text + "'"

            Conn.Open()
            Cmd.ExecuteNonQuery()
            Conn.Close()

            'Limpio variables
            txtNumero1.Text = ""
            txtNumero2.Text = ""
            resultado = vbEmpty

            Response.Redirect("WebForm_Resultado.aspx")

        End If

    End Sub
    Private Function ValidaDatos(numero1 As String, numero2 As String, operacion As String) As Boolean
        ValidaDatos = True
        If Not IsNumeric(numero1) Or Not IsNumeric(numero2) Then
            MsgBox("Debe ingresar numeros en los campos")
            ValidaDatos = False
            Exit Function
        End If

        If numero2 = 0 And operacion = "/" Then
            MsgBox("No se puede dividir por 0")
            ValidaDatos = False
        End If

        Return ValidaDatos
    End Function
End Class