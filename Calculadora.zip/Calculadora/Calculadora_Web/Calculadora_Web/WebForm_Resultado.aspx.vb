﻿Public Class WebForm2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub cmdAtras_Click1(sender As Object, e As EventArgs) Handles cmdAtras.Click
        Response.Redirect("WebForm_Operacion.aspx")
    End Sub
End Class