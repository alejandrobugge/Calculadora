﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CalculadoraCS
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private SqlConnection Conn;
        private SqlCommand Cmd;
        private SqlDataReader Reader;
        private string results;
        protected void Page_Load(object sender, EventArgs e)
        {
            Conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB; " + @"AttachDbFilename=|DataDirectory|\Calculadora.mdf;Integrated Security=True");
        }

        protected void cmdCalcular_Click(object sender, EventArgs e)
        {
            if (ValidaDatos(txtNumero1.Text, txtNumero2.Text, cboOperacion.Text))
            {
                Cmd = Conn.CreateCommand();
                double resultado;
                txtNumero1.Text = Strings.Replace(txtNumero1.Text, ",", ".");
                txtNumero2.Text = Strings.Replace(txtNumero2.Text, ",", ".");
                Cmd.CommandText = "exec sp_operacion " + txtNumero1.Text + "," + txtNumero2.Text + ",'" + cboOperacion.Text + "'";
                Conn.Open();
                Cmd.ExecuteNonQuery();
                Conn.Close();

                // Limpio variables
                txtNumero1.Text = "";
                txtNumero2.Text = "";
                resultado = 0;
                Response.Redirect("WebForm_Resultado.aspx");
            }
        }
        private bool ValidaDatos(string numero1, string numero2, string operacion)
        {
            bool ValidaDatosRet = default;
            ValidaDatosRet = true;
            if (!Information.IsNumeric(numero1) | !Information.IsNumeric(numero2))
            {
                Interaction.MsgBox("Debe ingresar numeros en los campos");
                ValidaDatosRet = false;
                return ValidaDatosRet;
            }

            if (Conversions.ToDouble(numero2) == 0d & operacion == "/")
            {
                Interaction.MsgBox("No se puede dividir por 0");
                ValidaDatosRet = false;
            }

            return ValidaDatosRet;
        }
    }
}