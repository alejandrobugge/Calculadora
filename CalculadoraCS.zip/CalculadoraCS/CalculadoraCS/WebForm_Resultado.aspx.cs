﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CalculadoraCS
{
    public partial class WebForm2 : Page
    {
        public WebForm2()
        {
            Load += Page_Load;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void cmdAtras_Click1(object sender, EventArgs e)
        {
            Response.Redirect("WebForm_Operacion.aspx");
        }
    }
}